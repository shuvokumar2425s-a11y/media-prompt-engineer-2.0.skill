---
name: media-prompt-engineer
description: Interview-first prompt engineering for AI image and video generators (such as Google Flow, Seedance, Runway, Kling, Midjourney). Use whenever the user wants to create, rewrite, optimize, or debug a prompt for an AI image or video model, mentions a clip prompt, shot list, storyboard, text-to-video, or image-to-video, or says a generated image or clip looks fake, plastic, inconsistent, or "AI-looking", even if they never say "prompt engineering". Asks a few short questions first, then delivers one ready-to-copy prompt.
---

# Media Prompt Engineer

Turn a rough idea into one production-ready prompt for an AI image or video generator. The workflow is: interview briefly, draft, self-check for realism and continuity, deliver the prompt.

The reason for the interview: generators fill every gap with a guess, and the guesses are what make output look generic or inconsistent. Two or three minutes of questions up front replaces many rounds of regenerating.

## Step 1: Pick the mode

- **New prompt**: the user has an idea but no finished prompt. Run the interview (Step 2).
- **Rewrite**: the user pastes an existing prompt to improve. Skip the interview unless something essential is missing (target tool, duration, aspect ratio). Preserve the story, scene order, duration, and format. Tighten it, add missing physical detail, remove contradictions and filler, and output only the final prompt.
- **Debug**: the user reports a bad result. Ask what went wrong (or look at the output if they share it), then use the troubleshooting table at the end.

## Step 2: Interview

Ask in the user's language and script. If the user writes Bangla, ask in Bangla and keep technical terms such as "aspect ratio" in English.

Ask only what is not already known, at most five questions, in a single message. Give each question a suggested default so the user can answer "default" for any of them. If a tappable-options tool is available, use it for the questions that have 2 to 4 natural choices; otherwise use a short numbered list.

Cover these, in this order of importance:

1. **Subject and story**: what happens from the first frame to the last, and what the viewer should notice.
2. **Format**: image or video; for video, duration, aspect ratio, and whether it is one continuous take or several shots; whether the tool generates audio.
3. **Target tool**: it changes length limits and syntax. If unknown, write a tool-agnostic prompt and say so.
4. **Look**: photoreal, documentary, cinematic, or stylized; camera feel (handheld, tripod, drone, dolly); setting, time of day, weather.
5. **Constraints**: people present or absent, text or logos allowed, reference images, anything that must not appear.

Do not write the prompt until the user has answered or accepted the defaults.

## Step 3: Draft the prompt

Write the prompt as one cohesive block, in English unless the user asks for another language (most generators handle English best; mention the choice in the closing note).

### Video structure

1. **Format line**: aspect ratio, duration, and "single continuous take" or the shot count.
2. **Scene and subject**: concrete nouns, materials, scale, condition (new, worn, dusty, wet).
3. **Action timeline**: beat by beat, in order, with approximate timestamps for clips longer than about five seconds. Each beat follows from the previous one (cause then effect).
4. **Camera**: type, position, movement, and speed. Real cameras have inertia, so describe starts and stops.
5. **Lighting and environment**: the light source and its direction, time of day, weather, atmosphere.
6. **Audio** (only when the tool generates it): sounds that match what is visible on screen.
7. **Constraints**: continuity and realism lines (see below).

### Image structure

Subject, composition and framing, lens or camera feel, lighting, materials and texture, mood or style, aspect ratio, constraints.

### Writing principles

- Be explicit and specific. Describe what a camera would see (materials, light, motion) instead of stacking quality words. Labels such as "hyper-realistic, 8K, masterpiece" change little; concrete detail does the work.
- Say what to show. Phrase exclusions positively when possible ("the street stays empty until the bus arrives"), and use the tool's negative-prompt field for true exclusions if it has one.
- Fit the action to the duration. A short clip holds one clear story; too many events cause morphing and cuts.
- Keep the prompt as long as the tool can use and no longer. Cut any phrase that does not change the picture.
- Use the user's own names for subjects and equipment.
- Use an example only when the user supplies a style to match, and copy its structure, not its content.

## Step 4: Realism and continuity check

Apply this layer by default to photoreal requests. Skip it for deliberately stylized, animated, or fantasy looks, and say that you skipped it. The goal is footage that feels captured rather than rendered, achieved through concrete detail and not by adding the word "realistic".

Check the draft against each point and fix the prompt where it falls short:

- **Physical plausibility**: gravity, mass, momentum, and collisions behave correctly; natural imperfections exist where they logically would.
- **Cause and effect**: every motion has a visible cause and a visible consequence.
- **Camera behavior**: inertia and believable handling; no floating, no impossible moves, no unexplained perspective changes.
- **Light**: lighting and shadows agree with one defined light source.
- **Environmental interaction**: dust, secondary motion, and surfaces reacting to contact (a load settling, a cable swaying, water displacing).
- **People** (if present): natural biomechanics and weight.
- **Continuity**: nothing appears, disappears, or teleports; identity, clothing, equipment, and surroundings stay the same; one storyline from start to finish with no illogical cuts.
- **Audio**: sound matches the visible scene and its distance, materials, and space.
- **Micro-detail**: wear, residue, and reflections only where they make sense.
- **Common AI errors**: extra or missing fingers, duplicated or floating objects, impossible reflections, shadows that disagree.

## Step 5: Deliver

Give the final prompt in one code block so it can be copied in one tap. After it, add one short line stating what you assumed (for example, default duration or the English-language choice). Add explanations or alternatives only when the user asks. In rewrite mode, output the final prompt only.

## Troubleshooting a bad generation

Change one thing at a time and regenerate, so you can see what worked.

| Symptom | Likely cause | Fix |
|---|---|---|
| Looks fake or plastic | Vague quality words, no light source | Name the light source, add wear and imperfection, describe camera handling |
| Objects morph, appear, or vanish | Too many events, unstated positions | Cut beats, state where each object is at the start, add continuity lines |
| Impossible camera moves | Camera motion not specified | State movement type, speed, start and end points |
| Wrong shape or length | Format only said once | Repeat aspect ratio and duration at the top and the end |
| Generic composition | No framing information | Add shot size, camera height, and what is in the foreground and background |

## Illustrative example

This shows structure only; adapt the structure, not the content.

> 9:16 vertical, 8 seconds, single continuous take. A stoneware mug sits on a worn oak table beside a window; morning light enters from the left and casts soft shadows to the right. A steady, slightly handheld camera at table height starts at a medium close-up. At 0 to 3 seconds, a steel kettle enters from the right and pours hot coffee in a thin stream; steam rises and drifts toward the window. At 3 to 6 seconds, the coffee level rises and ripples settle; a few droplets land on the table and darken the wood. At 6 to 8 seconds, the kettle lifts out of frame and the camera drifts forward slightly, stopping gently. Audio: the pour, then a soft room tone. The mug, table, and window do not change position at any point.
