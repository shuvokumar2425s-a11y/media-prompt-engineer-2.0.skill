# Media Prompt Engineer

An interview-first Claude Skill for writing, rewriting, and debugging prompts for AI image and video generators.

## Overview

AI image and video generators fill every gap in a prompt with a guess. Those guesses are why results look generic, why objects morph or vanish halfway through a clip, and why footage feels "AI-looking." Media Prompt Engineer closes the gaps before you generate anything. It asks a few short questions, drafts one production-ready prompt, checks it for realism and continuity, and returns it in a code block you can paste straight into your generator.

It is written for tools such as Google Flow, Seedance, Runway, Kling, and Midjourney. If you have not chosen a tool yet, it writes a tool-agnostic prompt and tells you so.

## Why it exists

Most weak generations share the same causes. The prompt describes a mood but not what a camera would actually see. The action has more events than the clip has seconds. The light has no source, the camera moves in ways no real camera can, and nothing says what must stay unchanged from the first frame to the last. A short interview surfaces exactly those missing details, which is cheaper than regenerating a clip five times and hoping.

## What it does

The Skill works in three modes and picks the right one from your message.

**New prompt.** You have an idea but no finished prompt. The Skill interviews you, then writes the prompt.

**Rewrite.** You paste a prompt that is almost right. The Skill skips the interview, keeps your story, scene order, duration, and format, removes contradictions and filler, adds missing physical detail, and returns only the improved prompt.

**Debug.** A generation came out wrong. The Skill asks what happened and maps the symptom to a fix, such as plastic-looking surfaces, morphing objects, impossible camera moves, or the wrong aspect ratio. Change one thing at a time so you can see what worked.

## How a session works

1. **Interview.** The Skill asks at most five questions in a single message and skips anything you have already said. Each question has a suggested default, so you can simply answer "default." The questions cover the story from first frame to last, the format (image or video, duration, aspect ratio, single take or several shots, audio), the target tool, the look and camera feel, and constraints such as people, text, logos, or reference images.
2. **Draft.** The prompt follows a fixed structure, described below.
3. **Check.** The draft is reviewed against a realism and continuity checklist and fixed wherever it falls short.
4. **Deliver.** You receive the final prompt in one code block, followed by a single line stating what was assumed. Explanations and alternatives appear only if you ask.

The interview runs in your language. If you write in Bangla, it asks in Bangla, while the final prompt is written in English by default because most generators handle English best. You can ask for another language at any time.

## What the prompts look like

Video prompts are ordered so that each part constrains the next: a format line (aspect ratio, duration, single take or shot count); the scene and subject with concrete materials and condition; a beat-by-beat action timeline, with approximate timestamps for longer clips; camera type and movement, including starts and stops; lighting and environment with a defined light source; audio that matches the visible action when the tool generates sound; and closing constraints.

Image prompts cover the subject, composition and framing, lens or camera feel, lighting, materials and texture, mood or style, aspect ratio, and constraints.

## The realism and continuity layer

For photoreal requests the Skill applies a checklist by default. The goal is footage that feels captured rather than rendered, achieved through concrete detail instead of the word "realistic." The checklist covers physical plausibility, visible cause and effect, believable camera inertia, lighting and shadows that agree with one source, environmental interaction such as dust and secondary motion, natural biomechanics when people appear, strict continuity (nothing appears, disappears, or teleports), audio that fits the scene, and a final scan for common AI errors such as extra fingers, duplicated or floating objects, and impossible reflections. For stylized, animated, or fantasy looks the layer is skipped, and the Skill says so.

## Design principles

The Skill follows Anthropic's published prompt engineering guidance, adapted for visual media: be explicit and specific, describe what the camera would see instead of stacking quality labels, say what to show rather than only what to avoid, keep each prompt as long as the tool can use and no longer, and use examples only when you supply a style to match. Fitting the action to the clip duration matters most, because a short clip holds one clear story.

## Installation

**Claude (web, desktop, mobile).** Download `media-prompt-engineer.skill` from the Releases page, or zip the `media-prompt-engineer` folder, and upload it in Claude's skills settings. Menu names vary by app version, so check Claude's current documentation if you cannot find the option.

**Claude Code.** Copy the `media-prompt-engineer` folder into `~/.claude/skills/` for personal use, or into `.claude/skills/` inside a project to share it with a team.

## Example requests

- "Write a prompt for a 10-second vertical video of a tower crane lifting a steel beam."
- "Rewrite this prompt for Google Flow, keeping the same story and duration."
- "My clip looks plastic and the camera floats. Help me fix the prompt."
- "I need a product photo prompt for a ceramic mug on a wooden table."

## Customizing

Everything lives in one `SKILL.md` file, so changes are easy. Shorten or lengthen the interview, change the default output language, remove the realism layer if you only make stylized work, or add your own house style as another section. Keep the description in the frontmatter specific about when the Skill should trigger.

## Limitations

This Skill writes prompts; it does not generate images or video. It has not been benchmarked across generators, and results vary by tool and model version, so treat every prompt as a strong first draft and iterate. Follow each platform's content policies and terms.

## Contributing

Issues and pull requests are welcome. Useful contributions include tool-specific notes, new troubleshooting rows, and real before-and-after examples.

## License

MIT. Not affiliated with or endorsed by Anthropic.
